#include <math.h>
#include <locale.h>
#include <iostream>
 
using namespace std;

double f1(double u1,double u2,double t, double m)
{
	return -u1*u2+sin(t)/t;
}

double f2(double u1,double u2,double t, double m)
{
	return -pow(u2,2) + m*t/(1+pow(t,2));
}
 
int main(int argc, char* argv[])
{
	// q = 48 // w = (25 < w < 48)
	// m =2.5+q/40
	double m = 3.7;
	double u1 = 0;
	double u2  = -0.412;
	double E1  = 0.001;
	double E2  = 0.001;
	double h;
	double h_max = 0.01;
	double h_min = 0.0001;
	double t = 0.0001;
	int i = 1;
	while(t<1)
		{
			double h1=E1/(fabs(f1(u1,u2,t,m))+(E1/h_max));
			double h2=E2/(fabs(f2(u1,u2,t,m))+(E2/h_max));
			if (h1<h2)
				h=h1;
			else
				h=h2;
			double u1_k = u1+h*f1(u1,u2,t,m);
			double u2_k = u2+h*f2(u1,u2,t,m);
			t=t+h;
			u1=u1_k;
			u2=u2_k;
			i=i+1;
		}

	cout<<"u1 = "<< u1 <<"\nu2 = "<< u2 <<"\nКоличество итераций i = "<<i<<endl;
}    
