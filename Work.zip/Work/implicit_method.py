#!/usr/bin/python
# -*- coding: UTF-8 -*-
import math
import numpy as np

def f1(u1, u2, t, m):
	return -u1*u2 + math.sin(t)/t


def f2(u1, u2, t, m):
	return -math.pow(u2,2)+m*t/(1+math.pow(t,2))

m=3.7 
h_min=0.0001
h_max = 0.01 
h=0.001
h_1=h
E=0.001
t=0
x=0
y=-0.412
x_1=x
y_1=y
u10=x
u20=y
D1=1
D2=1
i=1
err = math.pow(10,-3)
while(t<1):
	t_1=t+h
	D1=1
	D2=1
	while((D1>err) and (D2>err)):
		x0 = x
		y0 = y
		M = np.zeros((2,1))
		A = np.zeros((2,2))
		M[0] = x-x_1-h*(-x*y+math.sin(t_1)/t_1)
		M[1] = y-y_1-h*(math.pow(-y,2)+m*t_1/(1+math.pow(t_1,2)))
		A[0][0] = 1+h*y
		A[0][1] = h*x
		A[1][0] = 0
		A[1][1] = 1+2*h*y
		J=np.linalg.inv(A)
		dx=-J[0][0]*M[0]+ -J[0][1]*M[1]
		dy=-J[1][0]*M[0]+ -J[1][1]*M[1]
		x=x+dx
		y=y+dy
		d11=math.fabs(x-x0)
		d12=math.fabs(y-y0)
		if(d11>d12):
			D1=d11
		else: 
			D1=d12
		d21=math.fabs((x-x0)/x)
		d22=math.fabs((y-y0)/y)
		if(d21>d22):
			D2=d21
		else: 
			D2=d22  
	u1=u10+h*f1(x,y,t_1,m)
	u2=u20+h*f2(x,y,t_1,m)
	e1=-(h/(h+h_1))*(x-u10-(h/h_1)*(u10-x_1))
	e2=-(h/(h+h_1))*(y-u20-(h/h_1)*(u20-y_1))
	if(math.fabs(e1)>E or math.fabs(e2)>E):
		h=h/2
		t_1=t
		x=u10
		y=u20
	else:
		if(math.fabs(e1)>E):
			a=h/2
		else:
			if(math.fabs(e1)>E/4 and math.fabs(e1)<=E):
				a=h
			else:
				if(math.fabs(e1)<=E/4):
					a=2*h
		if(math.fabs(e2)>E):
			b=h/2
		else:
			if(math.fabs(e2)>E/4 and math.fabs(e2)<=E):
				b=h
			else:
				if(math.fabs(e2)<=E/4):
					b=2*h
		if(a>b):
			H=b
		else: 
			H=a
		if(H>h_max):
			H=h_max
		x=u1
		y=u2
		x_1=u10
		y_1=u20
		u10=x
		u20=y
		h_1=h
		h=H
		w=t
		t=t_1
	i=i+1


print("\nu1 = ", u1[0],"\nu2 = ", u2, "\nКол-во итераций: ",i,"\n")
