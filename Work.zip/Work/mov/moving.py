import matplotlib.pylab as plt
import matplotlib.animation as animation
import array as arr
import numpy as np
import math

n=0
i=0
fig=plt.figure()

x_ball=[] # Координаты шарика X
y_ball=[] # Координаты шарика Y
speed_ball=[] # Скорость шарика
delta_x=0.01 # Отклонение по X
delta_t=0.1 # Отклонение по времени
resistance=0.05 # Сопротивление
g=10 # Сила земного притяжения

y = np.loadtxt("y.txt", delimiter='\n', dtype=np.int) # Заводим массив Y
x = [] 
for n in range(len(y)): # Заводим массив X
    x.append(int(2*n))

tmp_x= float(input("Введите координату X: "))
if(tmp_x<0 or tmp_x>=200):
    print("Координата находится за графиком! Выходим из программы")
    exit(0)

def find_y(tmp_x):
    for k in range(0,100,1):
        if(tmp_x==x[k]):
            return y[k]
        if(tmp_x==x[k+1]):
            return y[k+1]
        if(tmp_x>x[k]):
            if(tmp_x<x[k+1]):
                a = ((tmp_x-x[k])*(y[k+1]-y[k])/(x[k+1]-x[k])+y[k])
                return a;


tmp_y=find_y(tmp_x)

def move(now_x, now_speed, prev_x):
    now_y=find_y(now_x) # Текущий Y
    if(now_y>tmp_y):
        now_speed = 0
        speed = 0
        now_x=prev_x
    a=g*(find_y(now_x)-find_y(now_x+delta_x))/pow(pow(find_y(now_x)-find_y(now_x+delta_x),2)+pow(delta_x,2),0.5) # g*sin(alfa), sin(alfa) = dY/(dY^2-dX^2)^(1/2)
    speed=now_speed+a*delta_t # v = v0 + at
    s=speed*delta_t # Путь, S = vt
    prev_x=now_x
    next_x=now_x+s/pow(((pow((find_y(now_x+delta_x)-find_y(now_x))/delta_x,2))+1),0.5)# x1 = x0 + S/((dY/dX)^2 + 1)^1/2
    speed-=s*resistance # Скорость уменьшается из-за сопротивления
    next_y=find_y(next_x) # Находим Y1 по X1
    x_ball.append(next_x) # Присваиваем шарику X
    y_ball.append(next_y) # Присваиваем шарику Y
    speed_ball.append(speed) # Присваиваем шарику скорость
    return next_x, speed, prev_x # Передаем текущее положение и скорость


def init(): # Инициализация шарика
 redDot.set_data([],[])
 return redDot,

def animate(i): # Анимация шарика
    if(i>=len(x_ball)):
        exit(0)
    redDot.set_data(x_ball[i], y_ball[i])
    return redDot,

def plot_ball(): # Считаем точки для шарика
    now_x=tmp_x
    l=0
    t_itr = 1
    speed=0
    prev_x=0
    x_ball.append(tmp_x)
    y_ball.append(tmp_y)
    speed_ball.append(0)
    while(abs(speed)>=2 or (find_y(now_x+delta_x)-find_y(now_x))/delta_x!=0):
        if (now_x<0):
            break
        (now_x,speed,prev_x) = move(now_x,speed,prev_x)
        l = l+1
        if (l>1000):
            break

plot_ball()

print("1. Построить график с движением шарика \n2. Построить график зависимости координаты X от скорости")

switch = int(input("Введите вариант: "))

if (switch == 1):
    ax=plt.axes(xlim=(0,200),ylim=(0,276))
    ax.plot(x,y)
    ax.grid()
    plt.xlabel('x[mm]')
    plt.xlabel('y[mm]')
    plt.title ('Moving the ball')
    redDot, = ax.plot([0], [0], 'ro')
    ani = animation.FuncAnimation(fig, animate, init_func=init,  interval=10, blit=True, repeat=True)
    plt.show()

if (switch == 2):
    plt.plot(speed_ball, x_ball)
    plt.grid()
    plt.xlabel('speed[mm/s]')
    plt.ylabel('x[mm]')
    plt.title ('Скорость от X')
    plt.show()
