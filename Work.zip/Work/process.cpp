#include <iostream>
#include <fstream>
#include <ctime>

#include <string>
#include <cstring>
#include <vector>
#include <iterator>
#include <cmath>

#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

using namespace std;

typedef struct {
	int processes_number;
	char input_prefix[64];
	char output_prefix[64];
	int vectors_number;
	int vectors_dimension;
} arguments;

int generate_vector(int vectors_dimension, vector<int> *vector)
{
	for (int i=0; i<vectors_dimension; i++)
	vector->push_back(rand() % 50);
	return 0;
}


int create_file(char* file_name, int vectors_number, int vectors_dimension){
	vector<int> vector_tmp;
	FILE *file = fopen(file_name, "w");
	for (int k = 0; k < vectors_number; k++) {

		generate_vector(vectors_dimension, &vector_tmp);
		for (int i = 0; i < vectors_dimension; i++) {
			fprintf(file, "%d ", vector_tmp.data()[i]);
		}
		fprintf(file, "\n");
		vector_tmp.clear();
	}
	fclose(file);
return 0;
}

int generate_file_names(int quant, string prefix, char names_files[][64])
{
	for (int i = 0; i < quant; ++i) {
		snprintf(names_files[i], 63, "%s%d", prefix.data(), i);
	}
	return 0;
}

int vector_sum(vector<int> *vectors, int vectors_number, vector<int> *sum){
	
	for (int i = 0; i < vectors_number; ++i) {
		for (int j = 0; j < vectors[i].size(); j++) {
			sum->data()[j] += vectors[i].data()[j];
		}
	}
return 0;

}

double vector_module(vector<int> *vector, double *module){

double sum = 0;
	
	for(int i = 0; i < vector->size(); i++) {
		sum += pow(vector->data()[i], 2);
	}
	*module = sqrt(sum);
return 0;

}

int calculate_for_file(char *input_file_name, int vectors_number, int vectors_dimention, vector<int> *vec_sum, double *vec_module,  clock_t &time)
{

	FILE *file = fopen(input_file_name, "r");
	vector<int> vectors[vectors_number];
	int tmp;
	for (int i = 0; i < vectors_number; i++) {
		for (int j = 0; j < vectors_dimention; j++) {
			fscanf(file, "%d", &tmp);
			vectors[i].push_back(tmp);		
		}
	}
	clock_t startTime = clock();
	vector_sum(vectors, vectors_number, vec_sum);
	vector_module(vec_sum, vec_module);
    	clock_t endTime = clock();
    	time = endTime - startTime;
	fclose(file);
	return 0;
}

int create_output_file(char *out_file_name, vector<int> sum, double module, int pid,  clock_t time, int ppid)
{	
	FILE *file = fopen(out_file_name, "w");
	fprintf(file, "sum: ");
	for (int i = 0; i < sum.size(); i++) { 
		fprintf(file, "%d ", sum.data()[i]);
	}
	fprintf(file, "\n");
	fprintf(file, "module: %lf\n", module);
	fprintf(file, "pid: %d\n", pid);
	fprintf(file, "duration of calculation: %d (ns)\n", int(time));
	fprintf(file, "ppid: %d\n", ppid);

	fclose(file);
	return 0;
}


int parse_args(int argc, char** argv, arguments* p_arg){

int opt;

while((opt = getopt(argc, argv, ":p:i:o:n:d:")) != -1) {
		switch (opt) {
		case 'p':
			p_arg->processes_number = atoi(optarg);
			break;
		case 'i':
			strncpy(p_arg->input_prefix, optarg, 64);
			break;
		case 'o':
			strncpy(p_arg->output_prefix, optarg, 64);
			break;
		case 'n':
			p_arg->vectors_number = atoi(optarg);
			break;
		case 'd':
			p_arg->vectors_dimension = atoi(optarg);
			break;     
		}
	}
	return 0;
}


main(int argc, char **argv)
{
	if (argc == 1) {
	cout<<" -p Число процессов \n -i Префикс входного файла \n -o Префикс выходного файла\n -n Число векторов \n -d Размер векторов\n";
	return 0;
	}
	
arguments args = {0};
parse_args(argc, argv, &args);

srand(time(NULL));
clock_t time;
char input_files[args.processes_number][64];
char output_files[args.processes_number][64];
generate_file_names(args.processes_number, args.input_prefix, input_files);
for(int i = 0; i < args.processes_number; ++i)
	create_file(input_files[i], args.vectors_number, args.vectors_dimension);
generate_file_names(args.processes_number, args.output_prefix, output_files);


for (int i = 0; i < args.processes_number; i++) {
		pid_t pid = fork();
 		if (pid == -1) {
			printf("Невозможно создать процесс\n");
			exit(1);
		}
		else if (pid == 0) {

			double module;
			vector<int> sum(args.vectors_dimension,0);
			calculate_for_file(input_files[i], args.vectors_number, args.vectors_dimension, &sum, &module, time);
			create_output_file(output_files[i], sum, module, getpid(), time, getppid());
			exit(0);
		}
for (int proc = 0; proc < args.processes_number; proc++) {
		int status;
		wait(&status);
	}
}


return 0;
}

