import matplotlib.pyplot as plt
import numpy as np


def setup(params):
	nx = params["coords"]["x_p"]
	ny = params["coords"]["y_p"]
	inside_distrib = params["global_temperature"]["inside"]
	
	src_size = params["source"]["size"]
	src_temp = params["source"]["temperature"]

	T = [[inside_distrib] * nx for j in range(ny)]

	for i in range(ny):
		T[i][-1] = params["side_temperature"]["right"]
		T[i][0] = params["side_temperature"]["left"]

	for i in range(nx):
		T[-1][i] = params["side_temperature"]["bottom"]
		T[0][i] = params["side_temperature"]["top"]
			
	midy = int(ny/2) 
	midx = int(nx/2)
	for i in range(src_size):
		for j in range(src_size):
			T[midy+i][midx+j] = src_temp
			T[midy-i][midx-j] = src_temp
			T[midy-i][midx+j] = src_temp
			T[midy+i][midx-j] = src_temp
	return T


def temperature_dist(params, current_dist):
	nx = params["coords"]["x_p"]
	ny = params["coords"]["y_p"]
	tau = params["duration"]["step"]
	a = params["a"]
	h = params["coords"]["step"]

	src_size = params["source"]["size"]
	T = current_dist

	midy = int(ny/2) 
	midx = int(nx/2)

	for i in range(1, ny-1):
		for j in range(1, nx-1):
			if(i < midy+src_size and i > midy-src_size and j < midx+src_size and j > midx-src_size):
				continue
			T[i][j] = int(T[i][j] + 
						 (tau * a / h**2) * 
						 ((T[i+1][j] - 2*T[i][j] + T[i-1][j]) + 
						  (T[i][j+1] - 2*T[i][j] + T[i][j-1])))	
	return T




def plot_res(params, inside_and_side_setup, im):
	time = 0
	time_end = params["duration"]["dur"]
	tau = params["duration"]["step"]
	min_temp = params["global_temperature"]["min"]
	max_temp = params["global_temperature"]["max"]
	
	T = inside_and_side_setup

	while time < time_end:
		time += tau
		T = temperature_dist(params, T)
	im.set_data(T)
	plt.show()
	return 0


def disp_res(params):
	min_temp = params["global_temperature"]["min"]
	max_temp = params["global_temperature"]["max"]

	inside_and_side_setup = setup(params)

	fig = plt.figure()
	im=plt.imshow(inside_and_side_setup, cmap='gist_rainbow_r', vmin=min_temp, vmax=max_temp)

	levels = np.arange(min_temp, max_temp, 100)
	c = plt.colorbar()
	c.set_ticks(levels)
	c.set_ticklabels(levels)
	res = plot_res(params, inside_and_side_setup, im)
	return res

def get_parameters():
	parameters = {   
		"a": 1.9,
		"coords": {
			"x_size": 50,
			"y_size": 50,
			"step": 1,
		},
		"duration": {
			"dur": 20,
			"step": 0.1
		},
		"side_temperature": {
			"left": 300,
			"right": 300,
			"top": 300,
			"bottom": 300
		},
		"source": {
			"temperature": 1200,
			"size": 4
		},
		"global_temperature": {
			"max": 1201,
			"min": 0,
			"inside": 0
		}
	}
	parameters["coords"]["x_p"] = int(parameters["coords"]["x_size"] / parameters["coords"]["step"])
	parameters["coords"]["y_p"] = int(parameters["coords"]["y_size"] / parameters["coords"]["step"])
	return parameters

def main():
	params = get_parameters()
	return disp_res(params)


if __name__ == "__main__":
	main()

